package com.ancely.modlerapp.basemvp;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.app.AlertDialog;

import com.ancely.modlerapp.basemvp.presenter.BasePresenter;

/*
 *  @项目名：  ModlerApp
 *  @包名：    com.ancely.modlerapp.basemvp
 *  @文件名:   BaseView
 *  @创建者:   fanlelong
 *  @创建时间:  2019/7/24 11:34 AM
 *  @描述：    View层基类 View层只会有Presenter引用
 */
public abstract class BaseView<P extends BasePresenter, CONTRACT> extends AlertDialog {

    protected P p;

    protected BaseView(@NonNull Context context) {
        super(context);
        init();
    }

    protected BaseView(@NonNull Context context, int themeResId) {
        super(context, themeResId);
        init();
    }

    protected void init() {
        p = getPresenter();

        //绑定
        p.bindView(this);

    }

    //让P层做什么需求
    public abstract CONTRACT getContract();

    public abstract P getPresenter();

    //如果Presneter层出现了异常,则需要告诉View;
    public void error(Exception e) {

    }

    @Override
    public void show() {
        super.show();
    }


    @Override
    public void dismiss() {
        super.dismiss();
        p.unBindView();
    }
}
