package com.ancely.modlerapp.basemvp.model;

import com.ancely.modlerapp.basemvp.presenter.BasePresenter;

/*
 *  @项目名：  ModlerApp
 *  @包名：    com.ancely.modlerapp.basemvp.model
 *  @文件名:   BaseModel
 *  @创建者:   fanlelong
 *  @创建时间:  2019/7/24 1:52 PM
 *  @描述：    //接收到P层过来的需求(基类)  Model层只会有Presenter引用
 */
public abstract class BaseModel<P extends BasePresenter, CONTRACT> {
    protected P p;


    //业务结束,通过Presneter调用契约,合同(接口中的方法)void resopnsResult(T t);

    public BaseModel(P p) {
        this.p = p;
    }

    public abstract CONTRACT getContract();
}
