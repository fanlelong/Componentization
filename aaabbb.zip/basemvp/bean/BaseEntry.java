package com.ancely.modlerapp.basemvp.bean;

/*
 *  @项目名：  ModlerApp
 *  @包名：    com.ancely.modlerapp.basemvp.bean
 *  @文件名:   BaseEntry
 *  @创建者:   fanlelong
 *  @创建时间:  2019/7/24 1:49 PM
 *  @描述：    TODO
 */
public class BaseEntry {
    String code;
    String error;
}
