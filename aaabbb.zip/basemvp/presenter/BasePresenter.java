package com.ancely.modlerapp.basemvp.presenter;

import com.ancely.modlerapp.basemvp.BaseView;
import com.ancely.modlerapp.basemvp.model.BaseModel;

import java.lang.ref.WeakReference;

/*
 *  @项目名：  ModlerApp
 *  @包名：    com.ancely.modlerapp.basemvp
 *  @文件名:   BasePresenter
 *  @创建者:   fanlelong
 *  @创建时间:  2019/7/24 11:34 AM
 *  @描述：    Presenter基类  P层即会有model层的引用,也会有View层的引用
 */
public abstract class BasePresenter<V extends BaseView, M extends BaseModel, CONTRACT> {

    protected M m;
    //绑定View的弱引用
    private WeakReference<V> mReference;

    public BasePresenter() {
        this.m = getModel();
    }

    public void bindView(V v) {
        mReference = new WeakReference<>(v);
    }

    public void unBindView() {
        if (mReference != null) {
            mReference.clear();
            mReference = null;
            System.gc();
        }
    }

    public V getView() {
        if (mReference != null) {
            return mReference.get();
        }
        return null;
    }

    //Model和View协商的共同业务
    public abstract CONTRACT getContract();

    public abstract M getModel();
}
