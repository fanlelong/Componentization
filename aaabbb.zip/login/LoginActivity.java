package com.ancely.modlerapp.login;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.ancely.modlerapp.R;
import com.ancely.modlerapp.annotation.ContentView;
import com.ancely.modlerapp.annotation.InjectView;
import com.ancely.modlerapp.annotation.OnClick;
import com.ancely.modlerapp.basemvp.BaseView;

/*
 *  @项目名：  ModlerApp
 *  @包名：    com.ancely.modlerapp.login
 *  @文件名:   LoginView
 *  @创建者:   fanlelong
 *  @创建时间:  2019/7/24 2:12 PM
 *  @描述：    TODO
 */
@ContentView(R.layout.activity_login)
public class LoginActivity extends BaseView<LoginPresenter, LoginContract.View> {
    @InjectView(R.id.login_accound)
    private EditText mAccound;

    @InjectView(R.id.login_pwd)
    private EditText mPwd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    protected void init() {

    }

    @OnClick(R.id.login_btn)
    public void onClick(View view) {
        String accound = mAccound.getText().toString();
        String pwd = mPwd.getText().toString();
        p.getContract().requestLogin(accound, pwd);
    }

    @Override
    public LoginContract.View getContract() {
        return (LoginContract.View<UserInfo>) userInfo -> {
            if (userInfo != null) {
                Toast.makeText(LoginActivity.this, userInfo.toString(), Toast.LENGTH_SHORT).show();
            }else{
                Toast.makeText(LoginActivity.this, "登陆失败", Toast.LENGTH_SHORT).show();
            }
        };
    }

    @Override
    public LoginPresenter getPresenter() {
        return new LoginPresenter();
    }
}
