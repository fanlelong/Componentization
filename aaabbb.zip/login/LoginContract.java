package com.ancely.modlerapp.login;

import com.ancely.modlerapp.basemvp.bean.BaseEntry;

/*
 *  @项目名：  ModlerApp
 *  @包名：    com.ancely.modlerapp.login
 *  @文件名:   LoginContract
 *  @创建者:   fanlelong
 *  @创建时间:  2019/7/24 1:46 PM
 *  @描述：    登陆
 */
public interface LoginContract {
    interface Model {
        void execudeLogin(String accound, String psw) throws Exception;
    }

    interface View<T extends BaseEntry> {
        void handlerResult(T t);
    }

    interface Persenter<T extends BaseEntry> {
        void requestLogin(String accound, String psw);

        void resopnseResult(T t);
    }
}
