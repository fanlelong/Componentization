package com.ancely.modlerapp.login;

import com.ancely.modlerapp.basemvp.model.BaseModel;

/*
 *  @项目名：  ModlerApp
 *  @包名：    com.ancely.modlerapp.login
 *  @文件名:   LoginModel
 *  @创建者:   fanlelong
 *  @创建时间:  2019/7/24 2:11 PM
 *  @描述：    TODO
 */
public class LoginModel extends BaseModel<LoginPresenter, LoginContract.Model> {
    public LoginModel(LoginPresenter loginPresenter) {
        super(loginPresenter);
    }

    @Override
    public LoginContract.Model getContract() {
        return (accound, psw) -> {
            if ("ancely".equals(accound)&&"123456".equals(psw)){
                p.getContract().resopnseResult(new UserInfo("ancely","123456"));
            }else{
                p.getContract().resopnseResult(null);
            }
        };
    }
}
