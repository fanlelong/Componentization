package com.ancely.modlerapp.login;

import com.ancely.modlerapp.basemvp.presenter.BasePresenter;

/*
 *  @项目名：  ModlerApp
 *  @包名：    com.ancely.modlerapp.login
 *  @文件名:   LoginPresenter
 *  @创建者:   fanlelong
 *  @创建时间:  2019/7/24 2:11 PM
 *  @描述：    TODO
 */
public class LoginPresenter extends BasePresenter<LoginActivity, LoginModel, LoginContract.Persenter> {
    @Override
    public LoginContract.Persenter getContract() {
        return new LoginContract.Persenter<UserInfo>() {
            @Override
            public void requestLogin(String accound, String psw) {
                //三种风格  要不不做事,转发  要么自己做
                try {
                    m.getContract().execudeLogin(accound,psw);
                } catch (Exception ignored) {

                }

                //第二种 由每三方来做


                //第三种 自己做
            }

            @Override
            public void resopnseResult(UserInfo userInfo) {
                //不管谁完成,把结果给View
                if (getView() != null) {
                    getView().getContract().handlerResult(userInfo);
                }
            }
        };
    }

    @Override
    public LoginModel getModel() {
        return new LoginModel(this);
    }
}
